Npgsql Test Suite
-----------------

Written by Dave Page (dpage@postgresql.org)

This is a basic test program to help with the testing and debugging
of the PostgreSQL .NET data provider, Npgsql. It has been written using
Microsoft Visual Studio .NET but with a little luck will hopefully work 
with Mono as well (when they've sorted System.Windows) :-)
