Npgsql - .NET Data Provider for PostgreSQL
=============

###What Is Npgsql?

Npgsql is a .Net Data Provider for PostgreSQL. It allows you to connect and interact with PostgreSQL server using .NET.


###Project Information

+   [Offical Site][1]
+   [Npgsql source code @ GitHub][2]
+   [Available on NuGet Gallery][3]
+   [Wiki - Usage and other information][4]


###Developers

Developers who contributes to Npgsql currently or in past, in no particular order:
    
+   Brar Piening
+   Francisco Figueiredo Jr.
+   Ben Clewett
+   Daniel Morgan
+   Dave Page
+   Ulrich Sprick
+   Glen Parker
+   Josh Cooley
+   Jon Asher
+   Chris Morgan
+   Thilo Utke
+   Hiroshi Saito
+   Shay Rojansky

###License

Refer LICENSE.txt for more information on license terms.

[1]: http://www.npgsql.org/  "Official site"
[2]: https://github.com/npgsql/Npgsql/  "Npgsql source code @ GitHub"
[3]: http://www.nuget.org/packages/Npgsql/ "Npgsql @ Nuget Gallery"
[4]: https://github.com/npgsql/Npgsql/wiki/  "Wiki"
