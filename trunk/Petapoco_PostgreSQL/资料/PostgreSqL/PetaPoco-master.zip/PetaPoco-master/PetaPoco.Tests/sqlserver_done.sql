﻿IF OBJECT_ID('dbo.petapoco','U') IS NOT NULL
	DROP TABLE dbo.petapoco;
IF OBJECT_ID('dbo.petapoco2','U') IS NOT NULL
	DROP TABLE dbo.petapoco2;

